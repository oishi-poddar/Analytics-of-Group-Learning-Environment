/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package net.jforum.sso;

/**
 *
 * @author Chirag
 */


import net.jforum.context.RequestContext;
import net.jforum.entities.UserSession;



public class MyAppSSO implements SSO{

public String authenticateUser(RequestContext request) {

String user = "";
user = (String)request.getSessionContext().getAttribute("username1");
System.out.println("username="+user);
//user = "chirag";
return user;

}

public boolean isSessionValid(UserSession userSession, RequestContext request) {

if(request.getSessionContext().getAttribute("username1") != null)

{

return true;

}
else
{

return false;

}

}

}